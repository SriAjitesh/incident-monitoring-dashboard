# Incident Monitoring Dashboard

A React + Firebase dashboard to track service status and response times.